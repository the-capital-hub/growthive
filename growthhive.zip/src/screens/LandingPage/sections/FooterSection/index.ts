export { FooterSection } from "./FooterSection";
